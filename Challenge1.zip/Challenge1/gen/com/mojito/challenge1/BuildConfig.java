/** Automatically generated file. DO NOT MODIFY */
package com.mojito.challenge1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}